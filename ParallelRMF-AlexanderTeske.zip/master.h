#ifndef MASTER_H
#define MASTER_H

void master(int p);

#endif
