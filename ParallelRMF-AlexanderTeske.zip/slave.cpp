#include <cmath>
#include <chrono>
#include <iostream>
#include <mpi.h>

#include "slave.h"
#include "RiskFeatureManager.h"
#include "MamdaniFuzzyInferenceSystem.h"
#include "TriangularLinguisticTerm.h"
#include "ExponentialRandomRiskFeature.h"
#include "TrapezoidalFuzzyRiskFeature.h"
#include "TriangularFuzzyRiskFeature.h"
#include "IntervalRiskFeature.h"
#include "UniformRandomRiskFeature.h"
#include "WeightedSumRiskFeature.h"

MamdaniFuzzyInferenceSystem initInferenceSystem(){
    //TODO: Fix case matching, e.g. CollisionFactor != CollisionFactor because some parts of the code store in ALL CAPS and some parts do not
    MamdaniFuzzyInferenceSystem mamdaniSystem = MamdaniFuzzyInferenceSystem();

    //Create input fuzzy variables
    auto collisionFactor = std::shared_ptr<FuzzyVariable>(new FuzzyVariable("COLLISIONFACTOR"));
    collisionFactor->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("HIGH", 0, 1, 1.5)));
    collisionFactor->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("MEDIUM", 0, 0.5, 1)));
    collisionFactor->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("LOW", -0.5, 0, 0.5)));

    auto degreeOfDistress = std::shared_ptr<FuzzyVariable>(new FuzzyVariable("DEGREEOFDISTRESS"));
    degreeOfDistress->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("HIGH", 0, 1, 1.5)));
    degreeOfDistress->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("MEDIUM", 0, 0.5, 1)));
    degreeOfDistress->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("LOW", -0.5, 0, 0.5)));

    auto seaState = std::shared_ptr<FuzzyVariable>(new FuzzyVariable("SEASTATE"));
    seaState->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("ROUGH", 0, 1, 1.5)));
    seaState->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("MODERATE", 0, 0.5, 1)));
    seaState->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("CALM", -0.5, 0, 0.5)));

    auto regionalHostility = std::shared_ptr<FuzzyVariable>(new FuzzyVariable("REGIONALHOSTILITY"));
    regionalHostility->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("HOSTILE", 0, 1, 1.5)));
    regionalHostility->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("NEUTRAL", 0, 0.5, 1)));
    regionalHostility->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("FRIENDLY", -0.5, 0, 0.5)));

    //Configure output
    std::shared_ptr<FuzzyVariable> output = mamdaniSystem.getOutputVariable();
    output->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("HIGH", 0.5, 1, 1.5)));
    output->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("MEDIUM", 0, 0.5, 1)));
    output->addLinguisticTerm(std::shared_ptr<TriangularLinguisticTerm>(new TriangularLinguisticTerm("LOW", -0.5, 0, 0.5)));

    //Add fuzzy rules to the FIS
    mamdaniSystem.addMamdaniFuzzyRule("IF COLLISIONFACTOR IS HIGH", "OVERALL_RISK IS HIGH");
    mamdaniSystem.addMamdaniFuzzyRule("IF DEGREEOFDISTRESS IS HIGH", "OVERALL_RISK IS HIGH");
    mamdaniSystem.addMamdaniFuzzyRule("IF SEASTATE IS ROUGH AND REGIONALHOSTILITY IS HOSTILE", "OVERALL_RISK IS HIGH");
    mamdaniSystem.addMamdaniFuzzyRule("IF REGIONALHOSTILITY IS HOSTILE", "OVERALL_RISK IS HIGH");
    mamdaniSystem.addMamdaniFuzzyRule("IF SEASTATE IS CALM", "OVERALL_RISK IS LOW");

    //Setup the FIS
    mamdaniSystem.addFuzzyVariable(collisionFactor);
    mamdaniSystem.addFuzzyVariable(degreeOfDistress);
    mamdaniSystem.addFuzzyVariable(seaState);
    mamdaniSystem.addFuzzyVariable(regionalHostility);

    return mamdaniSystem;
}

RiskFeatureManager initRiskExtraction(){
    RiskFeatureManager riskExtractionManager = RiskFeatureManager();

    //1. Collision Risk Feature
    auto collisionFactor = std::shared_ptr<TrapezoidalFuzzyRiskFeature>(new TrapezoidalFuzzyRiskFeature("COLLISIONFACTOR", "DISTANCETONEARESTSHIP", -10, 0, 50, 100));

    //2. Regional Hostility
    auto regionalHostility = std::shared_ptr<UniformRandomRiskFeature>(new UniformRandomRiskFeature("REGIONALHOSTILITY", 0, 0.2));

    //3. Sea State
    auto seaState = std::shared_ptr<ExponentialRandomRiskFeature>(new ExponentialRandomRiskFeature("SEASTATE", 0, 0.5));

    //4. Degree of distress
    auto degreeOfDistress = std::shared_ptr<WeightedSumRiskFeature>(new WeightedSumRiskFeature("DEGREEOFDISTRESS"));

    auto riskPersonel = std::shared_ptr<IntervalRiskFeature>(new IntervalRiskFeature("RISKPERSONEL", "NUMBEROFPEOPLEONBOARD"));
    riskPersonel->addInterval(0, 200, 0.5);
    riskPersonel->addInterval(200, std::numeric_limits<double>::max(), 1);

    auto fuelLevel = std::shared_ptr<TriangularFuzzyRiskFeature>(new TriangularFuzzyRiskFeature("FUELLEVEL", "FUELLEVEL", 0, 100, 101));

    degreeOfDistress->addRiskFeature(riskPersonel, 0.5);
    degreeOfDistress->addRiskFeature(fuelLevel, 0.5);

    riskExtractionManager.addRiskFeature(collisionFactor);
    riskExtractionManager.addRiskFeature(regionalHostility);
    riskExtractionManager.addRiskFeature(seaState);
    riskExtractionManager.addRiskFeature(degreeOfDistress);

    return riskExtractionManager;
}

void riskAssessment(int mpi_rank){
    MamdaniFuzzyInferenceSystem mamdaniSystem = initInferenceSystem();
    RiskFeatureManager riskFeatureManager = initRiskExtraction();
    int jobType;

    while (true){
        MPI_Recv(&jobType, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

        if (jobType == 0){
            std::cout<<"Processor: "<<mpi_rank<<" shutting down"<<std::endl;
            return;
        } else if (jobType == 1){
            int jobSize;
            MPI_Recv(&jobSize, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            double* input = new double[jobSize];
            MPI_Recv(input, jobSize, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

            int outputSize = jobSize / 4 * 2;
            double* output = new double[outputSize];
            int outputIndex = 0;

            for (int i = 0; i < jobSize; i = i + 4){
                std::string nearestVessel = std::to_string(input[i+1]);
                std::string numberOfPeopleOnboard = std::to_string(input[i+2]);
                std::string fuelLevel = std::to_string(input[i+3]);

                auto rawData = std::map<std::string, std::string>();
                rawData["DISTANCETONEARESTSHIP"] = nearestVessel;
                rawData["NUMBEROFPEOPLEONBOARD"] = numberOfPeopleOnboard;
                rawData["FUELLEVEL"] = fuelLevel;

                auto fisInput = riskFeatureManager.processRawData(rawData);
                double overallRisk = mamdaniSystem.computeFuzzyInferenceSystemOutput(fisInput);

                output[outputIndex++] = input[i];
                output[outputIndex++] = overallRisk;
            }

            MPI_Send(&outputSize, 1, MPI_INT, 0,0,MPI_COMM_WORLD);
            MPI_Send(output, outputSize, MPI_DOUBLE, 0,0,MPI_COMM_WORLD);
            delete[] input;
            delete[] output;
        }
    }
}

void slave(int p, int mpi_rank){
    //Do Risk Assessment
    riskAssessment(mpi_rank);
}
