#include <mpi.h>
#include <vector>
#include <algorithm>
#include <limits>
#include <chrono>
#include <iostream>

#include <fstream>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <thread>

#include "master.h"

struct Vessel{
    int id;
    int numberOfPeopleOnBoard;
    double fuelLevel;
    double distanceToNearestVessel;
    double longitude;
    double latitude;
};

std::map<int, Vessel> generateFakeVessels(int numVessels){

    auto vessels = std::map<int, Vessel>();

    for (int i = 0; i < numVessels; ++i)
    {
        double seed = (i*1.0/numVessels);
        Vessel aVessel;
        aVessel.id=i;

        //The value of the risk factors doesn't change the complexity of the
        //calculations, so it doesn't matter what we set them to
        aVessel.numberOfPeopleOnBoard=int(seed);
        aVessel.fuelLevel = seed;
        aVessel.distanceToNearestVessel = seed;

        vessels[aVessel.id] = aVessel;
    }

    return vessels;
}

void doRiskAssessment(int workers, const std::map<int, Vessel>* vessels){
    int calculations = vessels->size();
    int calculationsPerWorker = calculations/workers;
    int remainingCalculations = calculations % workers;
    auto vesselIterator = vessels->begin();

    //Send jobs to slaves
    for (int i = 0; i < workers; ++i){
        int workerIndex = i+1;
        int calculations = calculationsPerWorker;
        if (remainingCalculations > 0){
            calculations++;
            remainingCalculations--;
        }
        int jobInputSize = calculations * 4;
        double* jobInput = new double[jobInputSize];
        int jobInputIndex = 0;
        for (int j=0; j < calculations; ++j){
            Vessel aVessel = vesselIterator->second;
            jobInput[jobInputIndex++] = aVessel.id;
            jobInput[jobInputIndex++] = aVessel.distanceToNearestVessel;
            jobInput[jobInputIndex++] = aVessel.numberOfPeopleOnBoard;
            jobInput[jobInputIndex++] = aVessel.fuelLevel;
            ++vesselIterator;
        }
        int jobType = 1;
        MPI_Send(&jobType, 1, MPI_INT, workerIndex, 0, MPI_COMM_WORLD); //Tell slave to expect a job of type 2
        MPI_Send(&jobInputSize, 1, MPI_INT, workerIndex, 0, MPI_COMM_WORLD); //Tell slave the input size
        MPI_Send(jobInput, jobInputSize, MPI_DOUBLE, workerIndex, 0, MPI_COMM_WORLD); //Send the job
        delete[] jobInput;
    }

    //Collect answsers from slaves
    int answers = 0;
    while (answers < workers){
        int outputSize =100000;
        MPI_Status status;
        MPI_Recv(&outputSize, 1, MPI_INT, MPI_ANY_SOURCE, 0, MPI_COMM_WORLD, &status);
        int source = status.MPI_SOURCE;
        double* output = new double[outputSize];
        MPI_Recv(output, outputSize, MPI_DOUBLE, source, 0, MPI_COMM_WORLD, &status);

        ++answers;
        delete[] output;
    }
}

double riskAssessment(int p, const std::map<int, Vessel>* vessels){
    int workers = p-1;

    //Start Timer
    std::chrono::time_point<std::chrono::system_clock> start, end;
    start = std::chrono::system_clock::now();

    //Do risk assessment
    doRiskAssessment(workers, vessels);

    //End Timer
    end = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    return elapsed_seconds.count();
}

time_t stringToTime(std::string in){
    struct tm tm;
    in = "Mar 1 " + in + " 2000";
    strptime(in.c_str(), "%b %d %H:%M:%S %Y", &tm);
    return mktime(&tm);
}

std::string* splitString(std::string in){
    std::string* out = new std::string[4];
    std::string partial;
    int outIndex=0;
    for (int i = 0; i < in.size(); ++i){
        if (in[i] == ','){
            out[outIndex++] = partial;
            partial="";
        } else{
            partial += in[i];
        }
    }
    out[outIndex]=partial;
    return out;
}

void benchmarkWithRealData(int p, bool simulateRealTime){
    std::cout<<"Real data benchmark"<<std::endl;
    auto vessels = std::map<int, Vessel>();

    std::string line;
    std::ifstream infile("ais_sorted.csv");
    std::getline(infile, line);//burn the first line

    std::string outputFileName = "1thread_realdata_output.csv";
    std::ofstream outfile;
    outfile.open(outputFileName, std::ios::trunc);
    outfile.close();

    time_t real_start_time = time(0);
    time_t data_start_time;
    bool data_start_time_set = 0;

    while (std::getline(infile, line)){
        std::string* split = splitString(line);

        time_t real_time = time(0);
        time_t data_time = stringToTime(split[1]);

        if (data_start_time_set == 0){
            data_start_time = data_time;
            data_start_time_set=1;
        }

        double real_time_diff = difftime(real_time, real_start_time);
        double data_time_diff = difftime(data_time, data_start_time);

        while (simulateRealTime && real_time_diff < data_time_diff){
            std::this_thread::sleep_for(std::chrono::seconds(1));
            real_time = time(0);
            real_time_diff = difftime(real_time, real_start_time);

        }

        int vesselId = std::stoi(split[0]);
        double longitude = std::stod(split[2]);
        double latitude = std::stod(split[3]);

        Vessel aVessel;
        aVessel.id=vesselId;
        aVessel.fuelLevel=100;
        aVessel.numberOfPeopleOnBoard=10;
        aVessel.distanceToNearestVessel=5;
        aVessel.longitude = longitude;
        aVessel.latitude = latitude;

        int numberOfVesselsBefore = vessels.size();
        vessels[vesselId]=aVessel;
        int numberofVesselsAfter = vessels.size();

        if (numberOfVesselsBefore != numberofVesselsAfter){
            double execTime = riskAssessment(2, &vessels);
            outfile.open(outputFileName, std::ios::app);
            outfile<<vessels.size()<<","<<execTime<<"\n";
            outfile.close();
        }

        delete[] split;
    }

}

std::string fileName(int workers, int inputSize){
    std::string workersStr = std::to_string(workers);
    std::string inputSizeStr = std::to_string(inputSize);
    return "output_"+workersStr+"threads_"+inputSizeStr+"vessels"+".csv";
}

void benchmarkWithFakeData(int p, int inputSize, int iterations){
    std::cout<<"Fake data benchmark: "<<inputSize<<std::endl;
    auto vessels = generateFakeVessels(inputSize);

    std::string file = fileName(p-1, inputSize);

    std::ofstream outfile;
    outfile.open(file, std::ios::trunc);
    outfile.close();

    for (int threads = 2; threads <= p; ++threads){
        std::cout<<"running with "<<threads<<std::endl;
        for (int i = 0; i < iterations; ++i){
            double execTime = riskAssessment(threads, &vessels);
            outfile.open(file, std::ios::app);
            outfile<<threads<<","<<vessels.size()<<","<<execTime<<"\n";
            outfile.close();
        }
    }

}

void master(int p){
    //Start Timer
    std::chrono::time_point<std::chrono::system_clock> start, end;
    start = std::chrono::system_clock::now();

    //Do risk assessment
    benchmarkWithRealData(p, false);
    benchmarkWithFakeData(p, 100, 10);
    benchmarkWithFakeData(p, 1000, 10);
    benchmarkWithFakeData(p, 5000, 10);
    benchmarkWithFakeData(p, 10000, 10);

    //End Timer
    end = std::chrono::system_clock::now();
    std::chrono::duration<double> elapsed_seconds = end-start;
    std::time_t end_time = std::chrono::system_clock::to_time_t(end);
    std::cout << "MASTER TIME: " << elapsed_seconds.count() << "s\n";

    //Shutdown slaves
    for (int i = 1; i < p; ++i){
        int jobType = 0;
        MPI_Send(&jobType, 1, MPI_INT, i, 0, MPI_COMM_WORLD); //Tell slave to shut down
    }
}
