#ifndef SLAVE_H
#define SLAVE_H

void slave(int p, int mpi_rank);

#endif
