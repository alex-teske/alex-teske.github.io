#include <iostream>
#include <mpi.h>
#include <string>

#include "master.h"
#include "slave.h"

void runParallelRiskAssessment(int argc, char *argv[]){
    MPI::Init(argc, argv); //  Initialize MPI.
    int p = MPI::COMM_WORLD.Get_size(); //  Get the number of processes.
    int mpi_rank = MPI::COMM_WORLD.Get_rank(); //  Get the individual process ID.

    if (mpi_rank == 0){
        master(p);
    } else if (mpi_rank > 0){
        slave(p, mpi_rank);
    }

    MPI::Finalize();
}

int main(int argc, char *argv[])
{
    runParallelRiskAssessment(argc, argv);
}
