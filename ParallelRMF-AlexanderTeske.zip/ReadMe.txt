To compile:
mpiCC -std=c++11 *.cpp -o main

To run
mpiexec -np 2 main

Note: to run you need at least 2 processors (i.e. master and at least one slave)

Note2: The code for the RMF is redacted so this will not compile. Prof Dehne, if you need to see that code please email me.